﻿namespace PhysicsDemo
{
    /// <summary>
    /// 射线检测结果
    /// </summary>
    public struct RayCastResult
    {
        public Shape Entity;
        public float Fraction;
        public Vector Normal;
        public bool Hit;
    }
}
