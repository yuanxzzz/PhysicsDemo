﻿using System;

namespace BlackJack.PhysicsPractice
{
    /// <summary>
    /// 碰撞
    /// </summary>
    public struct CollisionResult
    {
        public RigidBody m_bodyA;
        public RigidBody m_bodyB;

        // TODO: 碰撞信息
        // 碰撞点、法线、切线等
    }

}
