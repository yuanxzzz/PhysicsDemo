﻿using UnityEngine;

namespace PhysicsDemo
{
    /// <summary>
    /// 射线检测结果
    /// </summary>
    public struct RayCastResult
    {
        public Shape Entity;
        public float Fraction;
        public Vector3 Normal;
        public bool Hit;
    }
}
